var FundTokenCrowdsale = artifacts.require("./FundTokenCrowdsale.sol");
var FundToken = artifacts.require("./FundToken.sol");

const timeTravel = function (time) {
  return new Promise((resolve, reject) => {
    web3.currentProvider.sendAsync({
      jsonrpc: "2.0",
      method: "evm_increaseTime",
      params: [time], // 86400 is num seconds in day
      id: new Date().getTime()
    }, (err, result) => {
      if(err){ return reject(err) }
      return resolve(result)
    });
  })
}

const mineBlock = function () {
  return new Promise((resolve, reject) => {
    web3.currentProvider.sendAsync({
      jsonrpc: "2.0",
      method: "evm_mine"
    }, (err, result) => {
      if(err){ return reject(err) }
      return resolve(result)
    });
  })
}

const toDec = 10**2;//toDec on the contract must match for test to work.

contract('FundTokenCrowdsale', function(accounts) {
  /* ------ Suite 1 - main ------ */
  it("buy should fail before start", async function() {
    var accountZeroBalance = 0;
    let fct = await FundTokenCrowdsale.deployed();
    let tkadr = await fct.token.call();
    let tk = await FundToken.at(tkadr);
    try {
      await fct.buyTokens(accounts[11], {from:accounts[11], value: 50000});
    } catch (e) {
      return true;
    }
    throw new Error("I should never see this!")
  });

  it("should have correct start rate", async function() {
    var accountZeroBalance = 0;
    let fct = await FundTokenCrowdsale.deployed();
    let tkadr = await fct.token.call();
    let tk = await FundToken.at(tkadr);
    await timeTravel(86400 * 37 + 6 * 3600);
    await mineBlock();
    let acc1balb4 = await tk.balanceOf.call(accounts[11]);
    await fct.buyTokens(accounts[11], {from:accounts[11], value: 50000*toDec});
    let acc1balafter = await tk.balanceOf.call(accounts[11]);
    var expected = acc1balb4.c[0] + 50000*1250*toDec;
    assert.equal(acc1balafter.c[0], expected, "first bonus wrong");
    
  });

  it("should have correct second bonus rate", async function() {
    var accountZeroBalance = 0;
    let fct = await FundTokenCrowdsale.deployed();
    let tkadr = await fct.token.call();
    let tk = await FundToken.at(tkadr);
    await timeTravel(86400/3);
    await mineBlock();
    acc1balb4 = await tk.balanceOf.call(accounts[12]);
    await fct.buyTokens(accounts[12], {from:accounts[12], value: 50000*toDec});
    acc1balafter = await tk.balanceOf.call(accounts[12]);
    expected = acc1balb4.c[0] + 50000*1150*toDec;
    assert.equal(acc1balafter.c[0], expected, "second bonus wrong");
  });
50
  it("should have correct third bonus rate", async function() {
    var accountZeroBalance = 0;
    let fct = await FundTokenCrowdsale.deployed();
    let tkadr = await fct.token.call();
    let tk = await FundToken.at(tkadr);
    await timeTravel(86400);
    await mineBlock();
    acc1balb4 = await tk.balanceOf.call(accounts[13]);
    await fct.buyTokens(accounts[13], {from:accounts[13], value: 15000*toDec});
    acc1balafter = await tk.balanceOf.call(accounts[13]);
    expected = acc1balb4.c[0] + 15000*1100*toDec;
    assert.equal(acc1balafter.c[0], expected, "second bonus wrong");
  });

  it("should have correct no bonus rate", async function() {
    var accountZeroBalance = 0;
    let fct = await FundTokenCrowdsale.deployed();
    let tkadr = await fct.token.call();
    let tk = await FundToken.at(tkadr);
    await timeTravel(86400*7);
    await mineBlock();
    acc1balb4 = await tk.balanceOf.call(accounts[11]); 
    await fct.buyTokens(accounts[11], {from:accounts[11], value: 13500*toDec});
    acc1balafter = await tk.balanceOf.call(accounts[11]);
    expected = acc1balb4.c[0] + 13500*1000*toDec;
    assert.equal(acc1balafter.c[0], expected, "second bonus wrong");
  });

  it("should not allow withdrawing lockup during sale", async function() {
    var accountZeroBalance = 0;
    let fct = await FundTokenCrowdsale.deployed();
    let tkadr = await fct.token.call();
    let tk = await FundToken.at(tkadr);
    try {
      await fct.withdrawLockupTokens({from:accounts[10]});
    } catch (e) {
      return true;
    }
    throw new Error("I should never see this!")
  });

  it("should not allow finalizing early", async function() {
    var accountZeroBalance = 0;
    let fct = await FundTokenCrowdsale.deployed();
    let tkadr = await fct.token.call();
    let tk = await FundToken.at(tkadr);
    try {
      await fct.finalize({from:accounts[10]});
    } catch (e) {
      return true;
    }
    throw new Error("I should never see this!")
  });

  it("should not allow finalizing for non admin on time", async function() {
    var accountZeroBalance = 0;
    let fct = await FundTokenCrowdsale.deployed();
    let tkadr = await fct.token.call();
    let tk = await FundToken.at(tkadr);
    await timeTravel(86400*23);
    await mineBlock();
    try {
      await fct.finalize({from:accounts[1]});
    } catch (e) {
      return true;
    }
    throw new Error("I should never see this!")
  });

  it("should allow finalizing after sale to admin and check sums", async function() {
    var accountZeroBalance = 0;
    let fct = await FundTokenCrowdsale.deployed();
    let tkadr = await fct.token.call();
    let tk = await FundToken.at(tkadr);

    let acc3balb4 = await tk.balanceOf.call(accounts[3]);
    let acc4balb4 = await tk.balanceOf.call(accounts[4]);
    let acc5balb4 = await tk.balanceOf.call(accounts[5]);
    let acc6balb4 = await tk.balanceOf.call(accounts[6]);
    let acc7balb4 = await tk.balanceOf.call(accounts[7]);
    let acc8balb4 = await tk.balanceOf.call(accounts[8]);
    let acc9balb4 = await tk.balanceOf.call(accounts[9]);

    await fct.finalize({from:accounts[10]});
    
    let acc3balaft = await tk.balanceOf.call(accounts[3]);
    let acc4balaft = await tk.balanceOf.call(accounts[4]);
    let acc5balaft = await tk.balanceOf.call(accounts[5]);
    let acc6balaft = await tk.balanceOf.call(accounts[6]);
    let acc7balaft = await tk.balanceOf.call(accounts[7]);
    let acc8balaft = await tk.balanceOf.call(accounts[8]);
    let acc9balaft = await tk.balanceOf.call(accounts[9]);

    assert.equal(acc3balaft.c[0], acc3balb4.c[0] + 10000000*toDec, "1 finalization sent incorrectly");
    assert.equal(acc4balaft.c[0], acc4balb4.c[0] + 4000000*toDec, "2 finalization sent incorrectly");
    assert.equal(acc5balaft.c[0], acc5balb4.c[0] + 2000000*toDec, "3 finalization sent incorrectly");
    assert.equal(acc6balaft.c[0], acc6balb4.c[0] + 200000*toDec, "4 finalization sent incorrectly");
    assert.equal(acc7balaft.c[0], acc7balb4.c[0] + 3800000*toDec, "5 finalization sent incorrectly");
    assert.equal(acc8balaft.c[0], acc8balb4.c[0] + 5000000*toDec, "6 finalization sent incorrectly");
    assert.equal(acc9balaft.c[0], acc9balb4.c[0] + 1000000*toDec, "7 finalization sent incorrectly");
  });

  it("should not allow withdrawing lockup during break", async function() {
    var accountZeroBalance = 0;
    let fct = await FundTokenCrowdsale.deployed();
    let tkadr = await fct.token.call();
    let tk = await FundToken.at(tkadr);
    try {
      await fct.withdrawLockupTokens({from:accounts[10]});
    } catch (e) {
      return true;
    }
    throw new Error("I should never see this!")
  });

  it("should not allow withdrawing for non admin on time", async function() {
    var accountZeroBalance = 0;
    let fct = await FundTokenCrowdsale.deployed();
    let tkadr = await fct.token.call();
    let tk = await FundToken.at(tkadr);
    await timeTravel(86400*180);
    await mineBlock();
    try {
      await fct.finalize({from:accounts[1]});
    } catch (e) {
      return true;
    }
    throw new Error("I should never see this!")
  });

  it("should allow withdrawing lockup tokens after period", async function() {
    var accountZeroBalance = 0;
    let fct = await FundTokenCrowdsale.deployed();
    let tkadr = await fct.token.call();
    let tk = await FundToken.at(tkadr);

    let acc3balb4 = await tk.balanceOf.call(accounts[0]);
    let acc4balb4 = await tk.balanceOf.call(accounts[1]);
    let acc5balb4 = await tk.balanceOf.call(accounts[2]);

    await fct.withdrawLockupTokens({from:accounts[10]});
    
    let acc3balaft = await tk.balanceOf.call(accounts[0]);
    let acc4balaft = await tk.balanceOf.call(accounts[1]);
    let acc5balaft = await tk.balanceOf.call(accounts[2]);

    assert.equal(acc3balaft.c[0], acc3balb4.c[0] + 4000000*toDec, "1. lockup withdrawn sent incorrectly");
    assert.equal(acc4balaft.c[0], acc4balb4.c[0] + 10000000*toDec, "2. lockup withdrawn incorrectly");
    assert.equal(acc5balaft.c[0], acc5balb4.c[0] + 10000000*toDec, "3. lockup withdrawn incorrectly");
    
  });
  /* ------ Suite 2 - finish on time ------ */
  // it("should airdrop with the correct ratios", async function() {
  //   let fct = await FundTokenCrowdsale.deployed();
  //   let tkadr = await fct.token.call();
  //   let tk = await FundToken.at(tkadr);
  //   await timeTravel(86400 * 47 + 17 * 3600);//start sale no bonus
  //   await mineBlock();
  //   await fct.buyTokens(accounts[11], {from:accounts[11], value: 68942*toDec});
  //   await fct.buyTokens(accounts[12], {from:accounts[12], value: 12367*toDec});
  //   await fct.buyTokens(accounts[13], {from:accounts[13], value: 29644*toDec});
  //   await fct.buyTokens(accounts[11], {from:accounts[11], value: 30620*toDec});
  //   let acc1 = await tk.balanceOf.call(accounts[11]);
  //   let acc2 = await tk.balanceOf.call(accounts[12]);
  //   let acc3 = await tk.balanceOf.call(accounts[13]);
  //   await timeTravel(86400 * 30);//sale time should run out
  //   await mineBlock();
  //   await fct.finalize({from:accounts[10]});
  //   let acc1n = await tk.balanceOf.call(accounts[11]);
  //   let acc2n = await tk.balanceOf.call(accounts[12]);
  //   let acc3n = await tk.balanceOf.call(accounts[13]);
  //   var drop1 = acc1n.sub(acc1);
  //   var drop2 = acc2n.sub(acc2);
  //   var drop3 = acc3n.sub(acc3);
  //   var rat1 = (acc1.div(drop1).div(acc2.div(drop2))) < 1.01 && (acc1.div(drop1).div(acc2.div(drop2))) > 0.99;
  //   console.log("ratio 1:");
  //   console.log(acc1.div(drop1).toString());
  //   console.log(acc2.div(drop2).toString());
  //   var rat2 = (acc1.div(drop1).div(acc3.div(drop3))) < 1.01 && (acc1.div(drop1).div(acc3.div(drop3))) > 0.99;
  //   console.log("ratio 2:");
  //   console.log(acc1.div(drop1).toString());
  //   console.log(acc3.div(drop3).toString());
  //   var rat3 = (drop1.div(drop2).div(acc1.div(acc2))) < 1.01 && (drop1.div(drop2).div(acc1.div(acc2))) > 0.99;
  //   console.log("ratio 3:");
  //   console.log(drop1.div(drop2).toString());
  //   console.log(acc1.div(acc2).toString());
  //   var rat4 = (drop1.div(drop3).div(acc1.div(acc3))) < 1.01 && (drop1.div(drop3).div(acc1.div(acc3))) > 0.99;
  //   console.log("ratio 4:");
  //   console.log(drop1.div(drop3).toString());
  //   console.log(acc1.div(acc3).toString());
    
  //   assert.equal(rat1, true, "ration 1 isnt preserved");
  //   assert.equal(rat2, true, "ration 2 isnt preserved");
  //   assert.equal(rat3, true, "ration 3 isnt preserved");
  //   assert.equal(rat4, true, "ration 4 isnt preserved");
  // });

  // it("should lock during break for minting and withdrawing lockup", async function() {
  //   let fct = await FundTokenCrowdsale.deployed();
  //   let tkadr = await fct.token.call();
  //   let tk = await FundToken.at(tkadr);
  //   var withdrawFailsDuringBreak = false;
  //   var mintFailsDuringBreak = false;
  //   try {
  //     await fct.withdrawLockupTokens({from:accounts[10]});
  //   } catch (e) {
  //     withdrawFailsDuringBreak = true;
  //   }
  //   try {
  //     await tk.mint.call(accounts[10], 10, {from:accounts[10]});
  //   } catch (e) {
  //     mintFailsDuringBreak = true;
  //   }
  //   await timeTravel(86400 * 180);//sale time should run out
  //   await mineBlock();
  //   await fct.withdrawLockupTokens({from:accounts[10]});
  //   assert.equal(withdrawFailsDuringBreak, true, "withdraw lockup succeeds during break");
  //   assert.equal(mintFailsDuringBreak, true, "minting succeeds during break");
  // });
  /* ------ Both ------ */
  it("should end up with 200000000*toDec total supply", async function() {
    var accountZeroBalance = 0;
    let fct = await FundTokenCrowdsale.deployed();
    let tkadr = await fct.token.call();
    let tk = await FundToken.at(tkadr);

    let acc0balb4 = await tk.balanceOf.call(accounts[0]);
    let acc1balb4 = await tk.balanceOf.call(accounts[1]);
    let acc2balb4 = await tk.balanceOf.call(accounts[2]);
    let acc3balb4 = await tk.balanceOf.call(accounts[3]);
    let acc4balb4 = await tk.balanceOf.call(accounts[4]);
    let acc5balb4 = await tk.balanceOf.call(accounts[5]);
    let acc6balb4 = await tk.balanceOf.call(accounts[6]);
    let acc7balb4 = await tk.balanceOf.call(accounts[7]);
    let acc8balb4 = await tk.balanceOf.call(accounts[8]);
    let acc9balb4 = await tk.balanceOf.call(accounts[9]);
    let acc10balb4 = await tk.balanceOf.call(accounts[10]);
    let acc11balb4 = await tk.balanceOf.call(accounts[11]);
    let acc12balb4 = await tk.balanceOf.call(accounts[12]);
    let acc13balb4 = await tk.balanceOf.call(accounts[13]);
    console.log(acc0balb4);
    console.log(acc1balb4);
    console.log(acc2balb4);
    console.log(acc3balb4);
    console.log(acc4balb4);
    console.log(acc5balb4);
    console.log(acc6balb4);
    console.log(acc7balb4);
    console.log(acc8balb4);
    console.log(acc9balb4);
    console.log(acc10balb4);
    console.log(acc11balb4);
    console.log(acc12balb4);
    console.log(acc13balb4);
    var tot = acc0balb4.c[0] + acc1balb4.c[0] + acc2balb4.c[0] + acc3balb4.c[0]
    tot = tot + acc4balb4.c[0] + acc5balb4.c[0] + acc6balb4.c[0];
    tot = tot + acc7balb4.c[0] + acc8balb4.c[0] + acc9balb4.c[0]
    tot = tot + acc10balb4.c[0] + acc11balb4.c[0] + acc12balb4.c[0] + acc13balb4.c[0];
    console.log(tot);
    assert.equal(tot, 200000000*toDec, "final total supply incorrect");
    
  });
  /* To be run on it's own */
 
});
