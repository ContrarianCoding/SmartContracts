
const FundTokenCrowdsale = artifacts.require("./FundTokenCrowdsale.sol")

module.exports = function(deployer, network, accounts) {

	deployer.deploy(FundTokenCrowdsale, accounts[10], accounts[9], accounts[8], accounts[7], accounts[6], accounts[5], accounts[4], accounts[3], accounts[2], accounts[1], accounts[0]);
};
