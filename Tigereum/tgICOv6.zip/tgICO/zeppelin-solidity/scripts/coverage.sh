#!/usr/bin/env bash

SOLIDITY_COVERAGE=true scripts/test.sh
