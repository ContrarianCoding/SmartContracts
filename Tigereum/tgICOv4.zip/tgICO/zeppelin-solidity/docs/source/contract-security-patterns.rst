Common Contract Security Patterns
=============================================

Zeppelin smart contracts are developed using industry standard contract security patterns and best practices. To learn more, please see `Onward with Ethereum Smart Contract Security <https://medium.com/zeppelin-blog/onward-with-ethereum-smart-contract-security-97a827e47702#.ybvzeyz0k/>`_.
